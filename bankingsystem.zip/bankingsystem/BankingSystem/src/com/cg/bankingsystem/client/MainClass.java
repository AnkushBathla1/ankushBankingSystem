package com.cg.bankingsystem.client;
import java.util.Scanner;
import javax.security.auth.login.AccountNotFoundException;
import com.cg.*;
import com.cg.bankingsystem.DbUtil.BankingServiceDbUtil;
import com.cg.bankingsystem.beans.Account;
import com.cg.bankingsystem.beans.Customer;
import com.cg.bankingsystem.exceptions.AccountBlockedException;
import com.cg.bankingsystem.exceptions.InvalidAccountNumberException;
import com.cg.bankingsystem.exceptions.InvalidAccountTypeException;
import com.cg.bankingsystem.exceptions.InvalidAdharNoException;
import com.cg.bankingsystem.exceptions.InvalidAmountException;
import com.cg.bankingsystem.exceptions.InvalidPinNumberException;
import com.cg.bankingsystem.services.ServiceImpl;
import com.cg.bankingsystem.services.Services;

public class MainClass {
	static  Scanner sc= new Scanner(System.in);
	static Services services=new ServiceImpl();
	public static void main(String args[]) throws InvalidAmountException, InvalidAccountTypeException, InvalidAccountNumberException,  InvalidPinNumberException, AccountBlockedException, AccountNotFoundException {
	mainScreen();
	int userChoice=sc.nextInt();
	startMenu(userChoice);
	}
	public static void startMenu(int userChoice) throws InvalidAmountException, InvalidAccountTypeException,  InvalidAccountNumberException, InvalidPinNumberException, AccountBlockedException, AccountNotFoundException {

		switch(userChoice) {
		case 1:    System.out.println("Enter first name:");
		                String fName = sc.next();
		                System.out.println("Enter last name:");
		                String lName  = sc.next();
		                System.out.println("Enter Adhar Number:");
		            	String  adharNo = sc.next();
		            	if(adharNo.length()!=16&&adharNo.contains(adharNo))
							try {
								throw new InvalidAdharNoException();
							} catch (InvalidAdharNoException e) {}
		                System.out.println("Enter your pan number:");
		                String panNo = sc.next();
		                System.out.println("Enter mobile number:");
		                String mobileNo = sc.next();
		                System.out.println("");
			            System.out.println("Enter the type of account you want to open:");
						System.out.println("Note: Savings or Current");
						String accountType=sc.next();
						if(!accountType.equalsIgnoreCase("Saving")||accountType.equals("current"))
							{  
							try{
								throw new InvalidAccountTypeException();
							}catch(InvalidAccountTypeException e) {} }
						System.out.println("Enter your client Balance");
						double accountBalance=sc.nextDouble();
						Account account = services.createAccount(accountType,accountBalance,fName,lName,adharNo,panNo,mobileNo);
						System.out.println("******ACCOUNT CREATED******");
						System.out.println(account);
						break;
		case 2:   System.out.println("Enter the account number to deposit:");
                        long accountNumber=sc.nextLong();
                        if(!BankingServiceDbUtil.accountInfo.containsKey(accountNumber)) {
                        	try {
                        		throw new InvalidAccountNumberException();
                        	}catch(InvalidAccountNumberException e) {}
                        }
						System.out.println("Enter the amount to deposit:");
					    double amount = sc.nextDouble();
						System.out.println(services.deposit(accountNumber,amount));
						break;
		case 3:   System.out.println("Enter the account number to withdraw");
		                long accountNumber1 = sc.nextLong();
		                if(!BankingServiceDbUtil.accountInfo.containsKey(accountNumber1)) {
                        	try {
                        		throw new InvalidAccountNumberException();
                        	}catch(InvalidAccountNumberException e) {}
                        }
		                System.out.println("Enter the amount to withdraw");
		                double amount1 = sc.nextDouble();
		                Account acc= BankingServiceDbUtil.accountInfo.get(accountNumber1);
		                if(amount1>acc.getAccountBalance()) {
					    	try { throw new InvalidAmountException();
					    	}catch(InvalidAmountException e) {}
					    	}
		                System.out.println("Enter the pin to withdraw");
		                long pinNumber1= sc.nextLong();
		                if(pinNumber1!=acc.getPinNumber()) {
		                	try { throw new InvalidPinNumberException();
		                	     }catch(InvalidPinNumberException e) {}
		                }
		                System.out.println(services.withdraw(accountNumber1, pinNumber1, amount1));
		        		break;
		case 4:  System.out.println("Enter the account number from which to transfer:");
		                long  fromAccountNumber = sc.nextLong();
		                if(!BankingServiceDbUtil.accountInfo.containsKey(fromAccountNumber)) {
                        	try {
                        		throw new InvalidAccountNumberException();
                        	}catch(InvalidAccountNumberException e) {}
                        }
		                System.out.println("Enter the account number to which to transfer:");
		                long toAccountNumber = sc.nextLong();
		                if(!BankingServiceDbUtil.accountInfo.containsKey(toAccountNumber)) {
                        	try {
                        		throw new InvalidAccountNumberException();
                        	}catch(InvalidAccountNumberException e) {}
                        }
		                System.out.println("Enter the pin of withdraw account");
		                long pinOfWithdrawAccount = sc.nextLong();
		                Account acc1= BankingServiceDbUtil.accountInfo.get(fromAccountNumber);
		                if(pinOfWithdrawAccount!=acc1.getPinNumber()) {
		                	try { throw new InvalidPinNumberException();
		                	     }catch(InvalidPinNumberException e) {}
		                }
		                System.out.println("Enter the amount:");
		                amount = sc.nextDouble();
		                if(amount>acc1.getAccountBalance()) {
					    	try { throw new InvalidAmountException();
					    	}catch(InvalidAmountException e) {}
					    	}
		                services.fundtransfer(fromAccountNumber,toAccountNumber,pinOfWithdrawAccount,amount);
	                     break;	
		case 5:   System.out.println(services.getAllAccount());
		                break;
		case 6:  System.out.println("Enter Account Number:");
		               long accountNumber2 = sc.nextLong();
		               if(!BankingServiceDbUtil.accountInfo.containsKey(accountNumber2)) {
                       	try {
                       		throw new InvalidAccountNumberException();
                       	}catch(InvalidAccountNumberException e) {}
                       }
		               System.out.println(services.findOne(accountNumber2));
		               break;
		case 7: System.out.println("Enter Account Number:");
		              long accountNumber3=sc.nextLong();
		              if(!BankingServiceDbUtil.accountInfo.containsKey(accountNumber3)) {
                      	try {
                      		throw new InvalidAccountNumberException();
                      	}catch(InvalidAccountNumberException e) {}
                      }
		              System.out.println(services.getAllTransactions(accountNumber3));
		              break;
		default: 
						System.out.println("Invalid Choice,Please Try Again!!!!!!");
		}
		System.out.println("What do you want to do now ?");
		System.out.println("1. Continue");
		System.out.println("2. Exit");
		int choice =sc.nextInt();
		if(choice==2)
			System.exit(0);
		main(null);
	}
	public static void mainScreen(){
		System.out.println("___________________BANK OF PEOPLE__________________________________");
		System.out.println("Please enter any one of the given choices :");
		System.out.println("1. Create a account");
		System.out.println("2. Deposit money");
		System.out.println("3. Withdraw money");
		System.out.println("4. Fund transfer:");
		System.out.println("5. Show all accounts");
		System.out.println("6. Show Account Details:");
		System.out.println("7. Show transactions:");
	}
}