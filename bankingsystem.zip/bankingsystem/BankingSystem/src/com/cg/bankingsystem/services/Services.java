package com.cg.bankingsystem.services;
import javax.security.auth.login.AccountNotFoundException;
import com.cg.bankingsystem.beans.Transactions;
import com.cg.bankingsystem.beans.Account;
import com.cg.bankingsystem.exceptions.AccountBlockedException;
import com.cg.bankingsystem.exceptions.InvalidAccountNumberException;
import com.cg.bankingsystem.exceptions.InvalidAccountTypeException;
import com.cg.bankingsystem.exceptions.InvalidAmountException;
import com.cg.bankingsystem.exceptions.InvalidPinNumberException;
import java.util.*;
public interface Services {
public Account createAccount(String accountType,double accountBalance,String fName,String lName,String adharNo,String panNo,String mobileNo) 
 throws InvalidAccountTypeException,InvalidAmountException;
public double deposit(long accountNumber,double amount)
		throws InvalidAmountException,InvalidAccountNumberException,AccountBlockedException;
public double withdraw(long accountNumber,long pinNumber,double amount) 
		throws InvalidAccountNumberException,InvalidAmountException,InvalidPinNumberException,AccountBlockedException;
public void  fundtransfer(long fromAccountNumber,long toAccountNumber,long pinOfWithdrawAccount,double amount) 
		throws InvalidAccountNumberException,InvalidAmountException,InvalidPinNumberException, AccountBlockedException;
public List<Account> getAllAccount();
public List<Transactions>getAllTransactions(long accountNumber) throws AccountNotFoundException;
public Account findOne(long accountNumber) throws AccountNotFoundException;
}