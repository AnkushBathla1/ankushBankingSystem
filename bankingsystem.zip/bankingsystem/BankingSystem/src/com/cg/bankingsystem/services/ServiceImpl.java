package com.cg.bankingsystem.services;
import com.cg.bankingsystem.DbUtil.BankingServiceDbUtil;
import com.cg.bankingsystem.beans.Account;
import java.util.*;

import javax.security.auth.login.AccountNotFoundException;

import com.cg.bankingsystem.beans.Customer;
import com.cg.bankingsystem.exceptions.*;
import com.cg.bankingsystem.serviceDao.*;
import com.cg.bankingsystem.beans.Transactions;
public class ServiceImpl implements Services {
	ServiceDaoImpl serviceDaoImpl =new ServiceDaoImpl();
	@Override
	public Account createAccount(String accountType,double accountBalance,String fName,String lName,String adharNo,String panNo,String mobileNo) 
	     throws InvalidAccountTypeException,InvalidAmountException{
	    Account account = new Account(accountType, accountBalance,new Customer(fName,lName,adharNo,panNo,mobileNo));
	    account.transactions = new HashMap<>();
	    account = serviceDaoImpl.save(account);
		return account;
	}
	@Override
	public double withdraw(long accountNumber,long pinNumber,double amount)throws InvalidAccountNumberException,InvalidAmountException,InvalidPinNumberException,AccountBlockedException{
		    Transactions transactionWithdraw = new Transactions();
		    Account account = serviceDaoImpl.update(accountNumber);
		     account.setAccountBalance(account.getAccountBalance()-amount);
			 Long transactionId = BankingServiceDbUtil.getTransactionId();
		     transactionWithdraw.setTransactionId(transactionId);
			 transactionWithdraw.setAmount(amount);
		     transactionWithdraw.setTransactionType(BankingServiceDbUtil.getWithdrawTransactionType());
			 account.transactions.put(transactionId,transactionWithdraw);
		   	 serviceDaoImpl.stateSave(account);
			 System.out.println("Withdraw successful");
		     return account.getAccountBalance();
	}
	@Override
	public double deposit(long accountNumber,double amount)throws InvalidAmountException,InvalidAccountNumberException,AccountBlockedException{
		Transactions transactionDeposit = new Transactions();
		Account account1 = serviceDaoImpl.update(accountNumber);
	    account1.setAccountBalance(account1.getAccountBalance()+amount);
	    Long transactionId = BankingServiceDbUtil.getTransactionId();
		transactionDeposit.setTransactionId(transactionId);
		transactionDeposit.setAmount(amount);
		transactionDeposit.setTransactionType(BankingServiceDbUtil.getDepositTransactionType());
		account1.transactions.put(transactionId,transactionDeposit);
        serviceDaoImpl.stateSave(account1);
	    System.out.println("Deposit successful");
	    return account1.getAccountBalance();
	}
	@Override
	public void fundtransfer(long fromAccountNumber,long toAccountNumber,long pinOfWithdrawAccount,double amount) throws InvalidAmountException, InvalidAccountNumberException, InvalidPinNumberException,AccountBlockedException{
	double balanceOfWithdraw=	withdraw(fromAccountNumber, pinOfWithdrawAccount, amount);
	double balanceOfDeposit=deposit(toAccountNumber,amount);
	System.out.println("Balance after withdraw"+balanceOfWithdraw);
	System.out.println("Balance after deposit"+balanceOfDeposit);
	}
	public List<Account> getAllAccount(){
		return serviceDaoImpl.findAll();
	}
	public Account findOne(long accountNumber)throws AccountNotFoundException{
		return serviceDaoImpl.update(accountNumber);
	}
	public ArrayList<Transactions>getAllTransactions(long accountNumber)throws AccountNotFoundException{
		Account account= serviceDaoImpl.update(accountNumber);
		ArrayList transaction = new ArrayList<>(account.transactions.values());
		return transaction;
	}
}
