package com.cg.bankingsystem.exceptions;

public class InvalidAmountException extends Exception{
public InvalidAmountException() {
	System.out.println("Balance is not sufficient");
}
}
