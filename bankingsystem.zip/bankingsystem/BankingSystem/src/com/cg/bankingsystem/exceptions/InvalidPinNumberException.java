package com.cg.bankingsystem.exceptions;

public class InvalidPinNumberException extends Exception{
public InvalidPinNumberException() {
	System.out.println("please enter valid pin and if you enter incorrect pin 3 times , account will be blocked");
}
}
