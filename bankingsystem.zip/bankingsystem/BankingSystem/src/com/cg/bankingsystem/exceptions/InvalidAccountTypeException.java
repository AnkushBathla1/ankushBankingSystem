package com.cg.bankingsystem.exceptions;

public class InvalidAccountTypeException extends Exception{
public InvalidAccountTypeException() {
	System.out.println("Please choose Saving or Current");
}
}
