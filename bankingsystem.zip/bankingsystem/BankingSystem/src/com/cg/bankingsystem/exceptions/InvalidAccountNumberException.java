package com.cg.bankingsystem.exceptions;

public class InvalidAccountNumberException extends Exception{
public InvalidAccountNumberException() {
	System.out.println("Please enter valid account number.");
}
}
