package com.cg.bankingsystem.exceptions;

public class InvalidAdharNoException extends Exception {
public InvalidAdharNoException() {
	System.out.println("Adhar Number must be of 16 digits.");
}
}
